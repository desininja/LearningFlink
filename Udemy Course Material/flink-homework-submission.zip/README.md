Instructions
Assignment Link: https://github.com/DataExpert-io/data-engineer-handbook/blob/main/bootcamp/materials/4-apache-flink-training/homework/homework.md
Submission Deadline: no deadline assigned at the time of this template being downloaded. Please check your portal though so you don't miss it if it was added later.
GitHub Org: DataExpert-io
Repo Name: data-engineer-handbook

Files
No instructions or default files were provided for this assignment